# Portfolio · Lucía Marín Ortega

**Web publicada:** https://lucia-marin-dev.github.io/portfolio/  *(sustituir por la URL real)*

## Tecnologías
HTML5 semántico · CSS3 (variables de Bootstrap) · Bootstrap 5.3.3 · Bootstrap Icons 1.11.3 · JavaScript · GitHub Pages

## Paleta y contraste (WCAG 2.1 AA)
| Uso | Color | Combinación | Ratio |
|---|---|---|---|
| Primario (botones, navbar) | `#1D4E89` | blanco sobre azul | 8,6:1 |
| Hover primario | `#123761` | blanco sobre azul oscuro | 11,5:1 |
| Acento (títulos de sección) | `#8A3B12` | terracota sobre blanco | 7,3:1 |
| Texto | `#212529` | sobre blanco | 16,0:1 |
| Fondo suave | `#F1F5FA` | texto `#212529` sobre fondo | 14,5:1 |

> Las ratios son orientativas: **comprobarlas con WebAIM Contrast Checker** antes de entregar.

## Informe de calidad
Pendiente de completar con capturas **reales** en `docs/evidencias/`:
- [ ] Lighthouse (móvil)
- [ ] WAVE
- [ ] Validador HTML del W3C
- [ ] Validador CSS del W3C

## Uso de IA
Este proyecto es una solución de referencia generada con Claude (Anthropic) para uso docente. Si un estudiante lo toma como base, debe declarar aquí qué herramienta usó, para qué parte y por qué.

## Pendiente
Añadir `docs/cv.pdf` y sustituir imágenes SVG, enlaces y datos ficticios por los reales.
